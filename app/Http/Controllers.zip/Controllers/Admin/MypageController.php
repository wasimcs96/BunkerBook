<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Routing\Controller as BaseController;

class MypageController extends BaseController
{




    function index(){
         return view('mypage.index');
        // return view('frontEnd.index');
    }
    function index4(){
        return view('mypage.index4');
    }
    function index5(){
        return view('mypage.index5');
    }
    function index6(){
        return view('mypage.index6');
    }
    function index7(){
        return view('mypage.index7');
    }
    function index8(){
        return view('mypage.index8');
    }
    function index9(){
        return view('mypage.index9');
    }
    function index10(){
        return view('mypage.index10');
    }
}
